Some code with many error to challange student's PBO informatic UMM to resolve the code, so it can build without error.
