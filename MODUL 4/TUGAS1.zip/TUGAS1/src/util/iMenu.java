package util;

import data.Student;

import java.util.ArrayList;

public interface iMenu {
    void menu(ArrayList<Student> studentList);
}
